@echo off
setlocal
chcp 65001 >nul
title ctf-purge-fusion installer
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY (
  echo [x] 未找到 Python。请安装 Python 3.9+ 后重试。
  pause
  exit /b 1
)
set /p ROOT=请输入 CTF 系统根目录（含 tools\ctf_os.py，可拖入窗口）:
set "ROOT=%ROOT:"=%"
if "%ROOT%"=="" (
  echo [x] 没有输入目录。
  pause
  exit /b 1
)
%PY% "%~dp0install.py" --root "%ROOT%"
set "RC=%errorlevel%"
echo.
if not "%RC%"=="0" (
  echo [x] 安装未完成，退出码 %RC%。日志在 %~dp0logs
) else (
  echo [ok] 安装完成。记得重启 CTF 系统 MCP 后才会看到 redteam_* 工具。
)
pause
exit /b %RC%
