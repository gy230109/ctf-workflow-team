#!/bin/sh
# ctf-purge-fusion installer (wrapper; logic lives in install.py)
set -e
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ROOT=${1:-}
if [ -z "$ROOT" ]; then
  printf 'usage: sh install.sh /path/to/ctf-root [--dry-run|--uninstall|--no-skills]\n'
  exit 2
fi
shift || true
PY=python3
command -v "$PY" >/dev/null 2>&1 || PY=python
exec "$PY" "$HERE/install.py" --root "$ROOT" "$@"
