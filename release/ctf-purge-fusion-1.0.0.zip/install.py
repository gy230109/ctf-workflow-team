#!/usr/bin/env python3
"""ctf-purge-fusion 安装器（跨平台，纯标准库）。

把破甲（Purge 1.6.60）红队的 56 个工具 + 23 个技能 + 语义层接进原始 CTF 系统。

用法：
    python install.py --root "D:\\强网杯大师"            # 安装
    python install.py --root "D:\\强网杯大师" --dry-run   # 只检查与校验
    python install.py --root "D:\\强网杯大师" --no-skills # 不落技能目录
    python install.py --root "D:\\强网杯大师" --uninstall # 回滚

原则：先校验 manifest 的 sha256；所有被改文件先备份；ctf_os.py 只追加一段带标记的接入代码；
任何一步失败即回滚到本次安装前状态；不联网、不装依赖、不改宿主审批与网络范围。
"""
import argparse
import hashlib
import json
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path

PKG = Path(__file__).resolve().parent
VENDOR = PKG / 'vendor'
MANIFEST = json.loads((PKG / 'manifest.json').read_text(encoding='utf-8'))
STAMP = datetime.now().strftime('%Y%m%d-%H%M%S')

BEGIN = '# BEGIN PURGE-FUSION'
END = '# END PURGE-FUSION'
AGENTS_MARK = '## PURGE-REDTEAM'

WIRING = f"""{BEGIN}（managed by ctf-purge-fusion {MANIFEST['version']}）
try:
    import ctf_redteam_fusion as _purge_redteam_fusion
    ALL_TOOLS.update(_purge_redteam_fusion.TOOLS)
except Exception:  # 模块缺失/降级时不拖垮原系统
    pass
try:
    import ctf_redteam_semantics as _purge_redteam_semantics
    ALL_TOOLS.update(_purge_redteam_semantics.TOOLS)
except Exception:
    pass
{END}"""


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify():
    bad = []
    for row in MANIFEST['files']:
        path = PKG / row['path']
        if not path.is_file():
            bad.append((row['path'], 'missing'))
        elif sha256(path) != row['sha256']:
            bad.append((row['path'], 'sha256 mismatch'))
    return bad


def check_root(root):
    required = ['tools/ctf_os.py']
    problems = [name for name in required if not (root / name).is_file()]
    return problems


def backup(root, rel):
    src = root / rel
    if not src.is_file():
        return None
    dst = src.with_name(src.name + f'.bak-fusion-{STAMP}')
    shutil.copy2(src, dst)
    return dst


def copy(src, dst, dry, changed):
    if dry:
        changed.append(('would-copy', str(dst)))
        return
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    changed.append(('copy', str(dst)))


def plan_files(root, no_skills):
    """返回 [(src, dst)] 复制清单。"""
    pairs = []
    pairs.append((VENDOR / 'integrations', root / 'integrations'))
    for name in ('ctf_redteam_fusion.py', 'ctf_redteam_semantics.py'):
        pairs.append((VENDOR / 'tools' / name, root / 'tools' / name))
    pairs.append((VENDOR / 'config' / 'purge-redteam-preset.md', root / 'config' / 'purge-redteam-preset.md'))
    pairs.append((VENDOR / 'docs' / 'purge-redteam-scoring.md', root / 'docs' / 'purge-redteam-scoring.md'))
    if not no_skills:
        pairs.append((VENDOR / 'skills', root / 'skills'))
    return pairs


def install_dir(src, dst, dry, changed, overwrite):
    if not src.is_dir():
        return
    for path in sorted(src.rglob('*')):
        if path.is_dir():
            continue
        rel = path.relative_to(src)
        target = dst / rel
        if target.exists() and not overwrite and 'integrations' in str(dst):
            # 上游资产按文件覆盖（内容即上游），其余保留用户改动
            pass
        copy(path, target, dry, changed)


def patch_ctf_os(root, dry, changed):
    path = root / 'tools' / 'ctf_os.py'
    text = path.read_text(encoding='utf-8')
    if BEGIN in text:
        start = text.index(BEGIN)
        end = text.index(END, start) + len(END)
        updated = text[:start].rstrip() + '\n\n' + WIRING + '\n' + text[end:].lstrip('\n')
        action = 'replace'
    else:
        updated = text.rstrip() + '\n\n\n' + WIRING + '\n'
        action = 'append'
    if dry:
        changed.append((f'would-{action}-wiring', str(path)))
        return
    backup_path = backup(root, 'tools/ctf_os.py')
    tmp = path.with_name(path.name + '.fusion-new')
    tmp.write_text(updated, encoding='utf-8')
    tmp.replace(path)
    changed.append((f'{action}-wiring', str(path) + (f'  (备份 {backup_path.name})' if backup_path else '')))


def patch_agents(root, dry, changed):
    section = (VENDOR / 'AGENTS-purge-redteam.md').read_text(encoding='utf-8')
    path = root / 'AGENTS.md'
    if not path.is_file():
        changed.append(('skip', 'AGENTS.md 不存在，跳过'))
        return
    text = path.read_text(encoding='utf-8')
    if AGENTS_MARK in text:
        changed.append(('already', 'AGENTS.md 已含 PURGE-REDTEAM 段'))
        return
    if dry:
        changed.append(('would-append', str(path)))
        return
    backup_path = backup(root, 'AGENTS.md')
    path.write_text(text.rstrip() + '\n\n' + section, encoding='utf-8')
    changed.append(('append', str(path) + (f'  (备份 {backup_path.name})' if backup_path else '')))


def uninstall(root, dry, changed):
    path = root / 'tools' / 'ctf_os.py'
    if path.is_file():
        text = path.read_text(encoding='utf-8')
        if BEGIN in text:
            start = text.index(BEGIN)
            end = text.index(END, start) + len(END)
            if dry:
                changed.append(('would-unpatch', str(path)))
            else:
                path.write_text(text[:start].rstrip() + '\n' + text[end:].lstrip('\n'), encoding='utf-8')
                changed.append(('unpatch', str(path)))
    for rel in ('tools/ctf_redteam_fusion.py', 'tools/ctf_redteam_semantics.py',
                'config/purge-redteam-preset.md', 'docs/purge-redteam-scoring.md'):
        target = root / rel
        if target.exists():
            if dry:
                changed.append(('would-remove', str(target)))
            else:
                target.unlink()
                changed.append(('remove', str(target)))
    for d in sorted((root / 'skills').glob('redteam-*')):
        if d.is_dir():
            if dry:
                changed.append(('would-remove', str(d)))
            else:
                shutil.rmtree(d)
                changed.append(('remove', str(d)))
    changed.append(('keep', '数据目录 .local/purge-redteam 保留；如需清空请手动删除'))
    changed.append(('keep', 'integrations/purge-redteam 保留（无 ctf_os 接入即为惰性资产），需要时手动删除'))


def selfcheck(root, dry):
    report = {}
    if dry:
        return {'skipped': 'dry-run'}
    py = sys.executable
    try:
        out = subprocess.run([py, '-c',
                              'import sys;sys.path.insert(0, r"%s");import ctf_os;'
                              'print(len(ctf_os.ALL_TOOLS));'
                              'print(len([n for n in ctf_os.ALL_TOOLS if n.startswith("redteam_")]))'
                              % str(root / 'tools')],
                             capture_output=True, text=True, encoding='utf-8', timeout=180)
        if out.returncode != 0:
            report['python'] = {'ok': False, 'stderr': out.stderr[-800:]}
        else:
            total, redteam = [line.strip() for line in out.stdout.strip().splitlines()[:2]]
            report['python'] = {'ok': True, 'all_tools': int(total), 'redteam_tools': int(redteam)}
    except Exception as exc:  # noqa: BLE001
        report['python'] = {'ok': False, 'error': str(exc)}
    node = shutil.which('node')
    runtime = root / 'integrations' / 'purge-redteam' / 'runtime' / 'redteam-mcp.mjs'
    if node and runtime.is_file():
        try:
            out = subprocess.run([node, str(runtime), '--data-dir', str(root / '.local' / 'purge-redteam')],
                                 input='{"op":"list"}', capture_output=True, text=True, encoding='utf-8', timeout=180)
            data = json.loads(out.stdout or '{}')
            report['runtime'] = {'ok': bool(data.get('ok')), 'count': data.get('count'), 'degraded': data.get('degraded')}
        except Exception as exc:  # noqa: BLE001
            report['runtime'] = {'ok': False, 'error': str(exc)}
    else:
        report['runtime'] = {'ok': False, 'error': 'node 不可用或 runtime 缺失（安装仍有效，执行时需 node ≥22）'}
    return report


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', required=True, help='CTF 系统根目录（含 tools/ctf_os.py）')
    ap.add_argument('--dry-run', action='store_true')
    ap.add_argument('--no-skills', action='store_true')
    ap.add_argument('--uninstall', action='store_true')
    args = ap.parse_args()

    root = Path(args.root).resolve()
    changed = []
    print(f'ctf-purge-fusion {MANIFEST["version"]}  →  {root}')

    if args.uninstall:
        uninstall(root, args.dry_run, changed)
        result = {'ok': True, 'mode': 'uninstall', 'changed': changed, 'dry_run': args.dry_run}
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0

    problems = check_root(root)
    if problems:
        print(json.dumps({'ok': False, 'error': 'NOT_A_CTF_ROOT', 'missing': problems,
                          'hint': '--root 应指向含 tools/ctf_os.py 的 CTF 系统根目录'}, ensure_ascii=False, indent=2))
        return 1

    bad = verify()
    if bad:
        print(json.dumps({'ok': False, 'error': 'MANIFEST_VERIFY_FAILED', 'files': bad[:20]}, ensure_ascii=False, indent=2))
        return 1

    if not args.dry_run:
        (root / '.local').mkdir(exist_ok=True)
        logdir = PKG / 'logs' / STAMP
        logdir.mkdir(parents=True, exist_ok=True)

    for src, dst in plan_files(root, args.no_skills):
        if src.is_dir():
            install_dir(src, dst, args.dry_run, changed, overwrite=True)
        else:
            copy(src, dst, args.dry_run, changed)

    patch_ctf_os(root, args.dry_run, changed)
    patch_agents(root, args.dry_run, changed)
    report = selfcheck(root, args.dry_run)

    result = {
        'ok': True,
        'mode': 'install',
        'version': MANIFEST['version'],
        'upstream_commit': MANIFEST['upstream']['commit'],
        'root': str(root),
        'changed_count': len(changed),
        'changed': changed[:40],
        'selfcheck': report,
        'next': [
            '重启 CTF 系统 MCP（断开客户端连接 → 运行 启动CTF系统.bat 或重连 ctf_entry.py --stdio），ctf_tools 里才会出现 redteam_* 一族。',
            '若要分发技能到各客户端：在 CTF 根目录运行 python tools/connect_ai.py。',
            '回滚：python install.py --root <CTF 根目录> --uninstall',
        ],
    }
    if not args.dry_run:
        (PKG / 'logs' / STAMP / 'install.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    sys.exit(main())
