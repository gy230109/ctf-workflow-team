破甲 × CTF 系统 融合包（ctf-purge-fusion 1.0.0）
=================================================

把 dsh-purge（破甲）1.6.60 的红队能力完整接进你自己的 CTF 系统：
56 个 redteam_* 工具（各自 JSON Schema）+ 23 个红队技能 + 评分/角色/预设语义层，
与原有 ctf_* 工具共用一套 MCP、同一份 task_id 隔离。

上游：https://github.com/kingcharleslzy-ai/dsh-purge
上游提交：27919a326b6615b1968661a3e749760cec3a2e07
插件版本：1.6.60

使用
----
1. 解压到一个文件夹（不要在压缩包里直接运行）。
2. 双击 START.cmd。按提示输入 CTF 系统根目录（含 tools\ctf_os.py 的那一层），
   或直接把该目录拖进窗口。无需管理员权限。
3. 安装器会：
   - 逐个核对 manifest.json 里每个文件的 SHA256（不通过就停）；
   - 备份将被改动的 ctf_os.py、AGENTS.md（*.bak-fusion-<时间戳>）；
   - 复制 integrations/purge-redteam（上游 lib/redteam + runtime + 23 playbook + schemas）、
     tools/ctf_redteam_fusion.py、tools/ctf_redteam_semantics.py、
     skills/redteam-*（23 个）、config/purge-redteam-preset.md、docs/purge-redteam-scoring.md；
   - 在 ctf_os.py 末尾追加一段带标记的接入代码（# BEGIN PURGE-FUSION … # END PURGE-FUSION）；
   - 在 AGENTS.md 追加 PURGE-REDTEAM 段（已有则跳过）；
   - 自检：导入 ctf_os 看工具总数与 redteam_* 数量，跑一次 runtime 的 {"op":"list"}。
4. 自检通过后，**重启 CTF 系统的 MCP**（断开客户端连接 → 运行 启动CTF系统.bat
   或重连 tools\ctf_entry.py --stdio），ctf_tools 里才会出现 redteam_* 一族。
5. 想把 23 个红队技能同时装到 Codex / Trae / WorkBuddy / Claude / Cursor：
   在 CTF 根目录执行 python tools\connect_ai.py

要求
----
- Python ≥ 3.9（只用标准库）
- Node ≥ 22（runtime 用到 node:sqlite；没有 node 也能装，只是工具执行时会报缺运行时）
- 不联网、不装依赖、不改宿主审批/网络范围/系统执行策略

只检查不安装
------------
python install.py --root "你的 CTF 根目录" --dry-run

命令行安装（Linux/macOS 同款）
------------------------------
sh install.sh "/path/to/ctf-root"
python install.py --root "/path/to/ctf-root" --no-skills   # 不落技能目录

回滚
----
python install.py --root "你的 CTF 根目录" --uninstall

会摘掉 ctf_os.py 的接入块、删除本次新增的模块/技能/文档；
integrations/purge-redteam 与 .local/purge-redteam（资产数据）默认保留，需要时手动删。

边界（写清楚，不糊）
--------------------
- 技能可用性只到 probe 级（PATH 上有没有那个二进制），不代表工具可打。
- 红队评分与 CTF WP 评分是两套量纲，只并存不合并，也不替代平台判题。
- 没搬 DSH 面板 UI（ctf 系统没有对应插槽）；没执行 preset 组合逻辑，只做只读提取。
- 上游是 MIT；本包只做接入适配，不改上游业务逻辑（lib/redteam 保持原样可校验）。

日志与备份
----------
- 安装日志：本包 logs\<时间戳>\install.json
- 文件备份：被改文件同目录 *.bak-fusion-<时间戳>
