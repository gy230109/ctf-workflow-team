<#
.SYNOPSIS
  ctf-purge-fusion 安装器（PowerShell 包装，实际逻辑在 install.py）
.EXAMPLE
  .\install.ps1 -Root 'D:\强网杯大师'
  .\install.ps1 -Root 'D:\强网杯大师' -DryRun
  .\install.ps1 -Root 'D:\强网杯大师' -Uninstall
#>
param(
    [Parameter(Mandatory = $true)][string]$Root,
    [switch]$DryRun,
    [switch]$Uninstall,
    [switch]$NoSkills
)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new()
$py = (Get-Command python -ErrorAction SilentlyContinue).Source
if (-not $py) { $py = (Get-Command py -ErrorAction SilentlyContinue).Source }
if (-not $py) { throw '未找到 Python 3.9+；请安装后重试' }
$args = @((Join-Path $PSScriptRoot 'install.py'), '--root', $Root)
if ($DryRun) { $args += '--dry-run' }
if ($Uninstall) { $args += '--uninstall' }
if ($NoSkills) { $args += '--no-skills' }
& $py @args
exit $LASTEXITCODE
