# 部署验收：流量工具与 WP 完整链路 — 中文 WP

- 题型：forensics
- 比赛：未填写
- 题号：ctf-04fca725df3de1d8
- 导出范围：本机完整证据包，未经对外审阅
- 解题状态：未由记录器判定；工具成功不等于答案正确。

## 解题概述

自建 PCAP：6包、1个TCP流及1个UDP流、HTTP对象导出、DNS查询和USB原始字段提取；所有数据导出由固定桥回传到D盘并自动附入WP。重复提醒与NoobCTF显式参考开关通过。不调用模型、不提交flag、不计比赛解题。

## 已验证

以下验证真实调用及证据完整性，过程结论以引用的实际输出为依据。

## 解题过程

### 步骤 3：forensics_pcap

时间：2026-10-16T04:33:04.015358+00:00；状态：成功返回；耗时：6584.2 ms。

操作编号：`c4c0dc081fc546e69f960136a8a57d19`。

**行动目的：** 部署自建样例验收：summary

**实际操作与结果：**
```text
参数：
{
  "action": "summary",
  "local_file": "[CTF_ROOT]\\.local\\ctf-system\\tasks\\ctf-04fca725df3de1d8\\attachments\\offline-demo.pcap",
  "wp_purpose": "部署自建样例验收：summary",
  "wp_case": "ctf-04fca725df3de1d8",
  "case": "ctf-04fca725df3de1d8"
}
实际返回：
{
  "ok": true,
  "data": {
    "ok": true,
    "action": "summary",
    "max_packets": 20000,
    "input_sha256": "6f3f02be4f944a14e2bb796d84bf6c74ae3299fc9faef8d9f6ebc44030e17bed",
    "scope": "仅离线分析所读包；不是穷尽检查或答案验证。",
    "packets_read": 6,
    "captured_frame_bytes": 499,
    "protocols": {
      "eth:ethertype:ip:tcp": 3,
      "eth:ethertype:ip:tcp:http": 1,
      "eth:ethertype:ip:tcp:http:data-text-lines": 1,
      "eth:ethertype:ip:udp:dns": 1
    },
    "output_truncated": false,
    "command": [
      "tshark",
      "-n",
      "-r",
      "/home/kali/ctf-workbench/cases/ctf-04fca725df3de1d8/input/offline-demo.pcap",
      "-c",
      "20000",
      "-T",
      "fields",
      "-E",
      "header=y",
      "-E",
      "quote=d",
      "-E",
      "separator=/t",
      "-e",
      "frame.number",
      "-e",
      "frame.len",
      "-e",
      "frame.protocols",
      "-e",
      "ip.src",
      "-e",
      "ipv6.src",
      "-e",
      "ip.dst",
      "-e",
      "ipv6.dst",
      "-e",
      "tcp.stream",
      "-e",
      "udp.stream"
    ],
    "stderr": "",
    "evidence_artifacts": [
      {
        "artifact": "work/pcap-summary-d3a961d62ca7.tsv",
        "sha256": "6985421d717c580a2c1ce6356c9eeb05ead7b17366db90335ff179ed9fed69d7",
        "kind": "data_export",
        "source": "Actual offline TShark output; original PCAP preserved"
      }
    ],
    "artifact": "work/pcap-summary-d3a961d62ca7.tsv",
    "sha256": "6985421d717c580a2c1ce6356c9eeb05ead7b17366db90335ff179ed9fed69d7"
  },
  "execution": {
    "run_id": "20261016T043301Z-d9c71669",
    "case_root": "/home/kali/ctf-workbench/cases/ctf-04fca725df3de1d8",
    "cwd": "/home/kali/ctf-workbench/cases/ctf-04fca725df3de1d8/work",
    "command": [
      "/home/kali/ctf-workbench/.venv-specialists/bin/python3",
      "../input/extension-worker-5bd1e2e23a667bb6.py",
      "../input/request-ddd7ba36c37c4d0c8dc267a0d3b7c6f1.json"
    ],
    "timeout_seconds": 60,
    "started_at_utc": "2026-10-16T04:33:02.765057+00:00",
    "returncode": 0,
    "timed_out": false,
    "duration_seconds": 0.305,
    "stdout_bytes": 1206,
    "stderr_bytes": 0,
    "output_truncated": false,
    "stdout": "{\"ok\": true, \"action\": \"summary\", \"max_packets\": 20000, \"input_sha256\": \"6f3f02be4f944a14e2bb796d84bf6c74ae3299fc9faef8d9f6ebc44030e17bed\", \"scope\": \"仅离线分析所读包；不是穷尽检查或答案验证。\", \"packets_read\": 6, \"captured_frame_bytes\": 499, \"protocols\": {\"eth:ethertype:ip:tcp\": 3, \"eth:ethertype:ip:tcp:http\": 1, \"eth:ethertype:ip:tcp:http:data-text-lines\": 1, \"eth:ethertype:ip:udp:dns\": 1}, \"output_truncated\": false, \"command\": [\"tshark\", \"-n\", \"-r\", \"/home/kali/ctf-workbench/cases/ctf-04fca725df3de1d8/input/offline-demo.pcap\", \"-c\", \"20000\", \"-T\", \"fields\", \"-E\", \"header=y\", \"-E\", \"quote=d\", \"-E\", \"separator=/t\", \"-e\", \"frame.number\", \"-e\", \"frame.len\", \"-e\", \"frame.protocols\", \"-e\", \"ip.src\", \"-e\", \"ipv6.src\", \"-e\", \"ip.dst\", \"-e\", \"ipv6.dst\", \"-e\", \"tcp.stream\", \"-e\", \"udp.stream\"], \"stderr\": \"\", \"evidence_artifacts\": [{\"artifact\": \"work/pcap-summary-d3a961d62ca7.tsv\", \"sha256\": \"6985421d717c580a2c1ce6356c9eeb05ead7b17366db90335ff179ed9fed69d7\", \"kind\": \"data_export\", \"source\": \"Actual offline TShark output; original PCAP preserved\"}], \"artifact\": \"work/pcap-summary-d3a961d62ca7.tsv\", \"sha256\": \"6985421d717c580a2c1ce6356c9eeb05ead7b17366db90335ff179ed9fed69d7\"}\n",
    "stderr": "",
    "guest_log": "/home/kali/ctf-workbench/cases/ctf-04fca725df3de1d8/results/20261016T043301Z-d9c71669.json",
    "guest_ip": "192.168.26.129",
    "transport_seconds": 0.656,
    "bridge_exit": 0,
    "case": "ctf-04fca725df3de1d8",
    "on": "kali",
    "transport": "verified_bridge"
  },
  "case": "ctf-04fca725df3de1d8",
  "upload_verified": true,
  "evidence_artifacts": [
    {
      "path": "[CTF_ROOT]\\.local\\bridge-runtime\\cases\\ctf-04fca725df3de1d8\\downloads\\20261016T043303Z-dfed7f90\\pcap-summary-d3a961d62ca7.tsv",
      "sha256": "6985421d717c580a2c1ce6356c9eeb05ead7b17366db90335ff179ed9fed69d7",
      "kind": "data_export",
      "source": "Actual offline TShark output; original PCAP preserved"
    }
  ],
  "capture_errors": []
}
```

原始证据 SHA256：`726a5bb1e24ca663557acfecbad26b97722cbe68c601c149512a88cf55421454`。

![步骤 3 的日志渲染图（非屏幕截图）](images/0003-log.png)

实际工具导出数据：[pcap-summary-d3a961d62ca7.tsv](data/8357e95bf44c4a808989b0e815aac3fa.tsv)。

### 步骤 5：forensics_pcap

时间：2026-10-16T04:33:10.616342+00:00；状态：成功返回；耗时：5352.6 ms。

操作编号：`c03ef55315c240fdb5e18b95c6f20138`。

**行动目的：** 部署自建样例验收：streams

**实际操作与结果：**
```text
参数：
{
  "action": "streams",
  "local_file": "[CTF_ROOT]\\.local\\ctf-system\\tasks\\ctf-04fca725df3de1d8\\attachments\\offline-demo.pcap",
  "wp_purpose": "部署自建样例验收：streams",
  "wp_case": "ctf-04fca725df3de1d8",
  "case": "ctf-04fca725df3de1d8"
}
实际返回：
{
  "ok": true,
  "data": {
    "ok": true,
    "action": "streams",
    "max_packets": 20000,
    "input_sha256": "6f3f02be4f944a14e2bb796d84bf6c74ae3299fc9faef8d9f6ebc44030e17bed",
    "scope": "仅离线分析所读包；不是穷尽检查或答案验证。",
    "streams": [
      {
        "protocol": "tcp",
        "stream_id": 0,
        "packets": 5,
        "first_frame": 1,
        "source": "192.0.2.1",
        "destination": "192.0.2.2"
      },
      {
        "protocol": "udp",
        "stream_id": 0,
        "packets": 1,
        "first_frame": 6,
        "source": "192.0.2.1",
        "destination": "192.0.2.2"
      }
    ],
    "total_streams": 2,
    "rows_limited": false,
    "output_truncated": false,
    "command": [
      "tshark",
      "-n",
      "-r",
      "/home/kali/ctf-workbench/cases/ctf-04fca725df3de1d8/input/offline-demo.pcap",
      "-c",
      "20000",
      "-T",
      "fields",
      "-E",
      "header=y",
      "-E",
      "quote=d",
      "-E",
      "separator=/t",
      "-e",
      "frame.number",
      "-e",
      "frame.len",
      "-e",
      "frame.protocols",
      "-e",
      "ip.src",
      "-e",
      "ipv6.src",
      "-e",
      "ip.dst",
      "-e",
      "ipv6.dst",
      "-e",
      "tcp.stream",
      "-e",
      "udp.stream"
    ],
    "stderr": "",
    "evidence_artifacts": [
      {
        "artifact": "work/pcap-streams-f44be68dbff7.tsv",
        "sha256": "6985421d717c580a2c1ce6356c9eeb05ead7b17366db90335ff179ed9fed69d7",
        "kind": "data_export",
        "source": "Actual offline TShark output; original PCAP preserved"
      }
    ],
    "artifact": "work/pcap-streams-f44be68dbff7.tsv",
    "sha256": "6985421d717c580a2c1ce6356c9eeb05ead7b17366db90335ff179ed9fed69d7"
  },
  "execution": {
    "run_id": "20261016T043308Z-78daac03",
    "case_root": "/home/kali/ctf-workbench/cases/ctf-04fca725df3de1d8",
    "cwd": "/home/kali/ctf-workbench/cases/ctf-04fca725df3de1d8/work",
    "command": [
      "/home/kali/ctf-workbench/.venv-specialists/bin/python3",
      "../input/extension-worker-5bd1e2e23a667bb6.py",
      "../input/request-3cf1dd70100a494ab65232e1d1fb2bd3.json"
    ],
    "timeout_seconds": 60,
    "started_at_utc": "2026-10-16T04:33:09.200251+00:00",
    "returncode": 0,
    "timed_out": false,
    "duration_seconds": 0.405,
    "stdout_bytes": 1301,
    "stderr_bytes": 0,
    "output_truncated": false,
    "stdout": "{\"ok\": true, \"action\": \"streams\", \"max_packets\": 20000, \"input_sha256\": \"6f3f02be4f944a14e2bb796d84bf6c74ae3299fc9faef8d9f6ebc44030e17bed\", \"scope\": \"仅离线分析所读包；不是穷尽检查或答案验证。\", \"streams\": [{\"protocol\": \"tcp\", \"stream_id\": 0, \"packets\": 5, \"first_frame\": 1, \"source\": \"192.0.2.1\", \"destination\": \"192.0.2.2\"}, {\"protocol\": \"udp\", \"stream_id\": 0, \"packets\": 1, \"first_frame\": 6, \"source\": \"192.0.2.1\", \"destination\": \"192.0.2.2\"}], \"total_streams\": 2, \"rows_limited\": false, \"output_truncated\": false, \"command\": [\"tshark\", \"-n\", \"-r\", \"/home/kali/ctf-workbench/cases/ctf-04fca725df3de1d8/input/offline-demo.pcap\", \"-c\", \"20000\", \"-T\", \"fields\", \"-E\", \"header=y\", \"-E\", \"quote=d\", \"-E\", \"separator=/t\", \"-e\", \"frame.number\", \"-e\", \"frame.len\", \"-e\", \"frame.protocols\", \"-e\", \"ip.src\", \"-e\", \"ipv6.src\", \"-e\", \"ip.dst\", \"-e\", \"ipv6.dst\", \"-e\", \"tcp.stream\", \"-e\", \"udp.stream\"], \"stderr\": \"\", \"evidence_artifacts\": [{\"artifact\": \"work/pcap-streams-f44be68dbff7.tsv\", \"sha256\": \"6985421d717c580a2c1ce6356c9eeb05ead7b17366db90335ff179ed9fed69d7\", \"kind\": \"data_export\", \"source\": \"Actual offline TShark output; original PCAP preserved\"}], \"artifact\": \"work/pcap-streams-f44be68dbff7.tsv\", \"sha256\": \"6985421d717c580a2c1ce6356c9eeb05ead7b17366db90335ff179ed9fed69d7\"}\n",
    "stderr": "",
    "guest_log": "/home/kali/ctf-workbench/cases/ctf-04fca725df3de1d8/results/20261016T043308Z-78daac03.json",
    "guest_ip": "192.168.26.129",
    "transport_seconds": 0.797,
    "bridge_exit": 0,
    "case": "ctf-04fca725df3de1d8",
    "on": "kali",
    "transport": "verified_bridge"
  },
  "case": "ctf-04fca725df3de1d8",
  "upload_verified": true,
  "evidence_artifacts": [
    {
      "path": "[CTF_ROOT]\\.local\\bridge-runtime\\cases\\ctf-04fca725df3de1d8\\downloads\\20261016T043310Z-1c2c9c65\\pcap-streams-f44be68dbff7.tsv",
      "sha256": "6985421d717c580a2c1ce6356c9eeb05ead7b17366db90335ff179ed9fed69d7",
      "kind": "data_export",
      "source": "Actual offline TShark output; original PCAP preserved"
    }
  ],
  "capture_errors": []
}
```

原始证据 SHA256：`17cf7ee9e71878c7c9a39eab1af3cc4a3ada4bc5b596cd1037798c1b4d547950`。

![步骤 5 的日志渲染图（非屏幕截图）](images/0005-log.png)

实际工具导出数据：[pcap-streams-f44be68dbff7.tsv](data/2472de4fea344353827683008a4fcd26.tsv)。

### 步骤 7：forensics_pcap

时间：2026-10-16T04:33:16.097216+00:00；状态：成功返回；耗时：4642.6 ms。

操作编号：`6332838a23dd4067b059498869d28fb7`。

**行动目的：** 部署自建样例验收：follow

**实际操作与结果：**
```text
参数：
{
  "action": "follow",
  "local_file": "[CTF_ROOT]\\.local\\ctf-system\\tasks\\ctf-04fca725df3de1d8\\attachments\\offline-demo.pcap",
  "wp_purpose": "部署自建样例验收：follow",
  "wp_case": "ctf-04fca725df3de1d8",
  "case": "ctf-04fca725df3de1d8"
}
实际返回：
{
  "ok": true,
  "data": {
    "ok": true,
    "action": "follow",
    "max_packets": 20000,
    "input_sha256": "6f3f02be4f944a14e2bb796d84bf6c74ae3299fc9faef8d9f6ebc44030e17bed",
    "scope": "仅离线分析所读包；不是穷尽检查或答案验证。",
    "stream_id": 0,
    "text": "\n===================================================================\nFollow: tcp,ascii\nFilter: tcp.stream eq 0\nNode 0: 192.0.2.1:40000\nNode 1: 192.0.2.2:80\n54\nGET /artifact.txt HTTP/1.1\r\nHost: evidence.example\r\n\r\n\n\t99\nHTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 15\r\nConnection: close\r\n\r\nctf-system-demo\n===================================================================\n",
    "output_truncated": false,
    "command": [
      "tshark",
      "-n",
      "-r",
      "/home/kali/ctf-workbench/cases/ctf-04fca725df3de1d8/input/offline-demo.pcap",
      "-c",
      "20000"
    ],
    "stderr": "",
    "evidence_artifacts": [
      {
        "artifact": "work/pcap-follow-a711a8cc41e2.txt",
        "sha256": "7fda2f801ad8e4dc97c4a6e0c8006aaba1a9bb1e103e8098ef5b8790abd51b8c",
        "kind": "data_export",
        "source": "Actual offline TShark output; original PCAP preserved"
      }
    ],
    "artifact": "work/pcap-follow-a711a8cc41e2.txt",
    "sha256": "7fda2f801ad8e4dc97c4a6e0c8006aaba1a9bb1e103e8098ef5b8790abd51b8c"
  },
  "execution": {
    "run_id": "20261016T043314Z-e992eb0d",
    "case_root": "/home/kali/ctf-workbench/cases/ctf-04fca725df3de1d8",
    "cwd": "/home/kali/ctf-workbench/cases/ctf-04fca725df3de1d8/work",
    "command": [
      "/home/kali/ctf-workbench/.venv-specialists/bin/python3",
      "../input/extension-worker-5bd1e2e23a667bb6.py",
      "../input/request-35830b04d11747829088cba9b9a44f95.json"
    ],
    "timeout_seconds": 60,
    "started_at_utc": "2026-10-16T04:33:15.154216+00:00",
    "returncode": 0,
    "timed_out": false,
    "duration_seconds": 0.219,
    "stdout_bytes": 1197,
    "stderr_bytes": 0,
    "output_truncated": false,
    "stdout": "{\"ok\": true, \"action\": \"follow\", \"max_packets\": 20000, \"input_sha256\": \"6f3f02be4f944a14e2bb796d84bf6c74ae3299fc9faef8d9f6ebc44030e17bed\", \"scope\": \"仅离线分析所读包；不是穷尽检查或答案验证。\", \"stream_id\": 0, \"text\": \"\\n===================================================================\\nFollow: tcp,ascii\\nFilter: tcp.stream eq 0\\nNode 0: 192.0.2.1:40000\\nNode 1: 192.0.2.2:80\\n54\\nGET /artifact.txt HTTP/1.1\\r\\nHost: evidence.example\\r\\n\\r\\n\\n\\t99\\nHTTP/1.1 200 OK\\r\\nContent-Type: text/plain\\r\\nContent-Length: 15\\r\\nConnection: close\\r\\n\\r\\nctf-system-demo\\n===================================================================\\n\", \"output_truncated\": false, \"command\": [\"tshark\", \"-n\", \"-r\", \"/home/kali/ctf-workbench/cases/ctf-04fca725df3de1d8/input/offline-demo.pcap\", \"-c\", \"20000\"], \"stderr\": \"\", \"evidence_artifacts\": [{\"artifact\": \"work/pcap-follow-a711a8cc41e2.txt\", \"sha256\": \"7fda2f801ad8e4dc97c4a6e0c8006aaba1a9bb1e103e8098ef5b8790abd51b8c\", \"kind\": \"data_export\", \"source\": \"Actual offline TShark output; original PCAP preserved\"}], \"artifact\": \"work/pcap-follow-a711a8cc41e2.txt\", \"sha256\": \"7fda2f801ad8e4dc97c4a6e0c8006aaba1a9bb1e103e8098ef5b8790abd51b8c\"}\n",
    "stderr": "",
    "guest_log": "/home/kali/ctf-workbench/cases/ctf-04fca725df3de1d8/results/20261016T043314Z-e992eb0d.json",
    "guest_ip": "192.168.26.129",
    "transport_seconds": 0.657,
    "bridge_exit": 0,
    "case": "ctf-04fca725df3de1d8",
    "on": "kali",
    "transport": "verified_bridge"
  },
  "case": "ctf-04fca725df3de1d8",
  "upload_verified": true,
  "evidence_artifacts": [
    {
      "path": "[CTF_ROOT]\\.local\\bridge-runtime\\cases\\ctf-04fca725df3de1d8\\downloads\\20261016T043315Z-6151f2e5\\pcap-follow-a711a8cc41e2.txt",
      "sha256": "7fda2f801ad8e4dc97c4a6e0c8006aaba1a9bb1e103e8098ef5b8790abd51b8c",
      "kind": "data_export",
      "source": "Actual offline TShark output; original PCAP preserved"
    }
  ],
  "capture_errors": []
}
```

原始证据 SHA256：`8c5793cb98bd7df36961c8c5af81a45a8237f3cf53d5e209f795c97a01b19f74`。

![步骤 7 的日志渲染图（非屏幕截图）](images/0007-log.png)

实际工具导出数据：[pcap-follow-a711a8cc41e2.txt](data/3951cc72e006487887ae91a238cb6d0f.txt)。

### 步骤 9：forensics_pcap

时间：2026-10-16T04:33:21.422498+00:00；状态：成功返回；耗时：4487.7 ms。

操作编号：`780a9315b415419ab7c5e6372699d9cd`。

**行动目的：** 部署自建样例验收：http_objects

**实际操作与结果：**
```text
参数：
{
  "action": "http_objects",
  "local_file": "[CTF_ROOT]\\.local\\ctf-system\\tasks\\ctf-04fca725df3de1d8\\attachments\\offline-demo.pcap",
  "wp_purpose": "部署自建样例验收：http_objects",
  "wp_case": "ctf-04fca725df3de1d8",
  "case": "ctf-04fca725df3de1d8"
}
实际返回：
{
  "ok": true,
  "data": {
    "ok": true,
    "action": "http_objects",
    "max_packets": 20000,
    "input_sha256": "6f3f02be4f944a14e2bb796d84bf6c74ae3299fc9faef8d9f6ebc44030e17bed",
    "scope": "离线导出的 HTTP 对象；压缩包内文件未运行，内容仍需分析验证。",
    "objects": [
      {
        "name": "artifact.txt",
        "bytes": 15,
        "sha256": "7d2785ba25ee680102502faa67a14961a09a95bc533daf6e8530f97a435b8fbb"
      }
    ],
    "count": 1,
    "output_truncated": false,
    "command": [
      "tshark",
      "-n",
      "-r",
      "/home/kali/ctf-workbench/cases/ctf-04fca725df3de1d8/input/offline-demo.pcap",
      "-c",
      "20000"
    ],
    "stderr": "",
    "evidence_artifacts": [
      {
        "artifact": "work/pcap-http-b7aaa310f761.zip",
        "sha256": "214a10e7eaa6e0a55f59711e05c02528caacccd8063ad1b4128556390e22a84c",
        "kind": "data_export",
        "source": "Actual offline TShark output; original PCAP preserved"
      }
    ],
    "artifact": "work/pcap-http-b7aaa310f761.zip",
    "sha256": "214a10e7eaa6e0a55f59711e05c02528caacccd8063ad1b4128556390e22a84c"
  },
  "execution": {
    "run_id": "20261016T043319Z-1757934c",
    "case_root": "/home/kali/ctf-workbench/cases/ctf-04fca725df3de1d8",
    "cwd": "/home/kali/ctf-workbench/cases/ctf-04fca725df3de1d8/work",
    "command": [
      "/home/kali/ctf-workbench/.venv-specialists/bin/python3",
      "../input/extension-worker-5bd1e2e23a667bb6.py",
      "../input/request-6d6991aad3bf4cd4b2ee9bd357d8294f.json"
    ],
    "timeout_seconds": 60,
    "started_at_utc": "2026-10-16T04:33:20.191198+00:00",
    "returncode": 0,
    "timed_out": false,
    "duration_seconds": 0.429,
    "stdout_bytes": 923,
    "stderr_bytes": 0,
    "output_truncated": false,
    "stdout": "{\"ok\": true, \"action\": \"http_objects\", \"max_packets\": 20000, \"input_sha256\": \"6f3f02be4f944a14e2bb796d84bf6c74ae3299fc9faef8d9f6ebc44030e17bed\", \"scope\": \"离线导出的 HTTP 对象；压缩包内文件未运行，内容仍需分析验证。\", \"objects\": [{\"name\": \"artifact.txt\", \"bytes\": 15, \"sha256\": \"7d2785ba25ee680102502faa67a14961a09a95bc533daf6e8530f97a435b8fbb\"}], \"count\": 1, \"output_truncated\": false, \"command\": [\"tshark\", \"-n\", \"-r\", \"/home/kali/ctf-workbench/cases/ctf-04fca725df3de1d8/input/offline-demo.pcap\", \"-c\", \"20000\"], \"stderr\": \"\", \"evidence_artifacts\": [{\"artifact\": \"work/pcap-http-b7aaa310f761.zip\", \"sha256\": \"214a10e7eaa6e0a55f59711e05c02528caacccd8063ad1b4128556390e22a84c\", \"kind\": \"data_export\", \"source\": \"Actual offline TShark output; original PCAP preserved\"}], \"artifact\": \"work/pcap-http-b7aaa310f761.zip\", \"sha256\": \"214a10e7eaa6e0a55f59711e05c02528caacccd8063ad1b4128556390e22a84c\"}\n",
    "stderr": "",
    "guest_log": "/home/kali/ctf-workbench/cases/ctf-04fca725df3de1d8/results/20261016T043319Z-1757934c.json",
    "guest_ip": "192.168.26.129",
    "transport_seconds": 0.813,
    "bridge_exit": 0,
    "case": "ctf-04fca725df3de1d8",
    "on": "kali",
    "transport": "verified_bridge"
  },
  "case": "ctf-04fca725df3de1d8",
  "upload_verified": true,
  "evidence_artifacts": [
    {
      "path": "[CTF_ROOT]\\.local\\bridge-runtime\\cases\\ctf-04fca725df3de1d8\\downloads\\20261016T043321Z-6f563491\\pcap-http-b7aaa310f761.zip",
      "sha256": "214a10e7eaa6e0a55f59711e05c02528caacccd8063ad1b4128556390e22a84c",
      "kind": "data_export",
      "source": "Actual offline TShark output; original PCAP preserved"
    }
  ],
  "capture_errors": []
}
```

原始证据 SHA256：`88b4101602a35027ba2e90fbbb580a1324d929ec37f96444b1e0bf81d36ed152`。

![步骤 9 的日志渲染图（非屏幕截图）](images/0009-log.png)

实际工具导出数据：[pcap-http-b7aaa310f761.zip](data/0f61675c4f8e4a3c9cbb2d4c4b4f14b9.zip)。

### 步骤 11：forensics_pcap

时间：2026-10-16T04:33:27.052551+00:00；状态：成功返回；耗时：4789.2 ms。

操作编号：`54d6231f9a0a4546ba39e591e44faf9a`。

**行动目的：** 部署自建样例验收：dns

**实际操作与结果：**
```text
参数：
{
  "action": "dns",
  "local_file": "[CTF_ROOT]\\.local\\ctf-system\\tasks\\ctf-04fca725df3de1d8\\attachments\\offline-demo.pcap",
  "wp_purpose": "部署自建样例验收：dns",
  "wp_case": "ctf-04fca725df3de1d8",
  "case": "ctf-04fca725df3de1d8"
}
实际返回：
{
  "ok": true,
  "data": {
    "ok": true,
    "action": "dns",
    "max_packets": 20000,
    "input_sha256": "6f3f02be4f944a14e2bb796d84bf6c74ae3299fc9faef8d9f6ebc44030e17bed",
    "scope": "仅离线分析所读包；不是穷尽检查或答案验证。",
    "rows": [
      {
        "frame.number": "6",
        "dns.id": "0x04d2",
        "dns.qry.name": "evidence.example",
        "dns.a": "",
        "dns.aaaa": "",
        "dns.txt": ""
      }
    ],
    "total_rows": 1,
    "rows_limited": false,
    "output_truncated": false,
    "command": [
      "tshark",
      "-n",
      "-r",
      "/home/kali/ctf-workbench/cases/ctf-04fca725df3de1d8/input/offline-demo.pcap",
      "-c",
      "20000",
      "-Y",
      "dns",
      "-T",
      "fields",
      "-E",
      "header=y",
      "-E",
      "quote=d",
      "-E",
      "separator=/t",
      "-e",
      "frame.number",
      "-e",
      "dns.id",
      "-e",
      "dns.qry.name",
      "-e",
      "dns.a",
      "-e",
      "dns.aaaa",
      "-e",
      "dns.txt"
    ],
    "stderr": "",
    "evidence_artifacts": [
      {
        "artifact": "work/pcap-dns-4a55631ea835.tsv",
        "sha256": "cd7bbf64c62ddba6b0c1a278a9bfa639fd707fe0e2082f21d70dbe9febd7d9e4",
        "kind": "data_export",
        "source": "Actual offline TShark output; original PCAP preserved"
      }
    ],
    "artifact": "work/pcap-dns-4a55631ea835.tsv",
    "sha256": "cd7bbf64c62ddba6b0c1a278a9bfa639fd707fe0e2082f21d70dbe9febd7d9e4"
  },
  "execution": {
    "run_id": "20261016T043324Z-ddae7920",
    "case_root": "/home/kali/ctf-workbench/cases/ctf-04fca725df3de1d8",
    "cwd": "/home/kali/ctf-workbench/cases/ctf-04fca725df3de1d8/work",
    "command": [
      "/home/kali/ctf-workbench/.venv-specialists/bin/python3",
      "../input/extension-worker-5bd1e2e23a667bb6.py",
      "../input/request-7695527144f945898aa89f3f1c2fe6db.json"
    ],
    "timeout_seconds": 60,
    "started_at_utc": "2026-10-16T04:33:25.767681+00:00",
    "returncode": 0,
    "timed_out": false,
    "duration_seconds": 0.54,
    "stdout_bytes": 1115,
    "stderr_bytes": 0,
    "output_truncated": false,
    "stdout": "{\"ok\": true, \"action\": \"dns\", \"max_packets\": 20000, \"input_sha256\": \"6f3f02be4f944a14e2bb796d84bf6c74ae3299fc9faef8d9f6ebc44030e17bed\", \"scope\": \"仅离线分析所读包；不是穷尽检查或答案验证。\", \"rows\": [{\"frame.number\": \"6\", \"dns.id\": \"0x04d2\", \"dns.qry.name\": \"evidence.example\", \"dns.a\": \"\", \"dns.aaaa\": \"\", \"dns.txt\": \"\"}], \"total_rows\": 1, \"rows_limited\": false, \"output_truncated\": false, \"command\": [\"tshark\", \"-n\", \"-r\", \"/home/kali/ctf-workbench/cases/ctf-04fca725df3de1d8/input/offline-demo.pcap\", \"-c\", \"20000\", \"-Y\", \"dns\", \"-T\", \"fields\", \"-E\", \"header=y\", \"-E\", \"quote=d\", \"-E\", \"separator=/t\", \"-e\", \"frame.number\", \"-e\", \"dns.id\", \"-e\", \"dns.qry.name\", \"-e\", \"dns.a\", \"-e\", \"dns.aaaa\", \"-e\", \"dns.txt\"], \"stderr\": \"\", \"evidence_artifacts\": [{\"artifact\": \"work/pcap-dns-4a55631ea835.tsv\", \"sha256\": \"cd7bbf64c62ddba6b0c1a278a9bfa639fd707fe0e2082f21d70dbe9febd7d9e4\", \"kind\": \"data_export\", \"source\": \"Actual offline TShark output; original PCAP preserved\"}], \"artifact\": \"work/pcap-dns-4a55631ea835.tsv\", \"sha256\": \"cd7bbf64c62ddba6b0c1a278a9bfa639fd707fe0e2082f21d70dbe9febd7d9e4\"}\n",
    "stderr": "",
    "guest_log": "/home/kali/ctf-workbench/cases/ctf-04fca725df3de1d8/results/20261016T043324Z-ddae7920.json",
    "guest_ip": "192.168.26.129",
    "transport_seconds": 0.843,
    "bridge_exit": 0,
    "case": "ctf-04fca725df3de1d8",
    "on": "kali",
    "transport": "verified_bridge"
  },
  "case": "ctf-04fca725df3de1d8",
  "upload_verified": true,
  "evidence_artifacts": [
    {
      "path": "[CTF_ROOT]\\.local\\bridge-runtime\\cases\\ctf-04fca725df3de1d8\\downloads\\20261016T043326Z-25a329be\\pcap-dns-4a55631ea835.tsv",
      "sha256": "cd7bbf64c62ddba6b0c1a278a9bfa639fd707fe0e2082f21d70dbe9febd7d9e4",
      "kind": "data_export",
      "source": "Actual offline TShark output; original PCAP preserved"
    }
  ],
  "capture_errors": []
}
```

原始证据 SHA256：`b74b89f77e2bc2ec103cf48b190b392a62fa2469726dee2a8c696bb7d9e92c25`。

![步骤 11 的日志渲染图（非屏幕截图）](images/0011-log.png)

实际工具导出数据：[pcap-dns-4a55631ea835.tsv](data/98f5862924304011908caf5370ff1f80.tsv)。

### 步骤 13：forensics_pcap

时间：2026-10-16T04:33:32.021413+00:00；状态：成功返回；耗时：4141.6 ms。

操作编号：`35f7cbbd0ce5414cb5041e0711c2fefa`。

**行动目的：** 部署自建样例验收：usb

**实际操作与结果：**
```text
参数：
{
  "action": "usb",
  "local_file": "[CTF_ROOT]\\.local\\ctf-system\\tasks\\ctf-04fca725df3de1d8\\attachments\\usb-demo.pcap",
  "wp_purpose": "部署自建样例验收：usb",
  "wp_case": "ctf-04fca725df3de1d8",
  "case": "ctf-04fca725df3de1d8"
}
实际返回：
{
  "ok": true,
  "data": {
    "ok": true,
    "action": "usb",
    "max_packets": 20000,
    "input_sha256": "48caa5a8cc3cecd1d0622f39fdc8fa127e55577c7ee1c4b70b5055f4c421348d",
    "scope": "USB 原始 capdata 与包号；不是自动恢复的键盘文本。字段支持取决于实际 TShark。",
    "rows": [
      {
        "frame.number": "1",
        "usb.device_address": "2",
        "usb.endpoint_address": "0x81",
        "usb.capdata": "0000040000000000"
      }
    ],
    "total_rows": 1,
    "rows_limited": false,
    "output_truncated": false,
    "command": [
      "tshark",
      "-n",
      "-r",
      "/home/kali/ctf-workbench/cases/ctf-04fca725df3de1d8/input/usb-demo.pcap",
      "-c",
      "20000",
      "-Y",
      "usb.capdata",
      "-T",
      "fields",
      "-E",
      "header=y",
      "-E",
      "quote=d",
      "-E",
      "separator=/t",
      "-e",
      "frame.number",
      "-e",
      "usb.device_address",
      "-e",
      "usb.endpoint_address",
      "-e",
      "usb.capdata"
    ],
    "stderr": "",
    "evidence_artifacts": [
      {
        "artifact": "work/pcap-usb-deb9b3c20ab5.tsv",
        "sha256": "526ecf8dccd07d02f9e9e515b3e9ad569cfc644ec9f0429319926172102027cd",
        "kind": "data_export",
        "source": "Actual offline TShark output; original PCAP preserved"
      }
    ],
    "artifact": "work/pcap-usb-deb9b3c20ab5.tsv",
    "sha256": "526ecf8dccd07d02f9e9e515b3e9ad569cfc644ec9f0429319926172102027cd"
  },
  "execution": {
    "run_id": "20261016T043330Z-c4a1a3bf",
    "case_root": "/home/kali/ctf-workbench/cases/ctf-04fca725df3de1d8",
    "cwd": "/home/kali/ctf-workbench/cases/ctf-04fca725df3de1d8/work",
    "command": [
      "/home/kali/ctf-workbench/.venv-specialists/bin/python3",
      "../input/extension-worker-5bd1e2e23a667bb6.py",
      "../input/request-4d61a216e9594c5a9ea0d97b7b4ef8e9.json"
    ],
    "timeout_seconds": 60,
    "started_at_utc": "2026-10-16T04:33:31.265990+00:00",
    "returncode": 0,
    "timed_out": false,
    "duration_seconds": 0.22,
    "stdout_bytes": 1145,
    "stderr_bytes": 0,
    "output_truncated": false,
    "stdout": "{\"ok\": true, \"action\": \"usb\", \"max_packets\": 20000, \"input_sha256\": \"48caa5a8cc3cecd1d0622f39fdc8fa127e55577c7ee1c4b70b5055f4c421348d\", \"scope\": \"USB 原始 capdata 与包号；不是自动恢复的键盘文本。字段支持取决于实际 TShark。\", \"rows\": [{\"frame.number\": \"1\", \"usb.device_address\": \"2\", \"usb.endpoint_address\": \"0x81\", \"usb.capdata\": \"0000040000000000\"}], \"total_rows\": 1, \"rows_limited\": false, \"output_truncated\": false, \"command\": [\"tshark\", \"-n\", \"-r\", \"/home/kali/ctf-workbench/cases/ctf-04fca725df3de1d8/input/usb-demo.pcap\", \"-c\", \"20000\", \"-Y\", \"usb.capdata\", \"-T\", \"fields\", \"-E\", \"header=y\", \"-E\", \"quote=d\", \"-E\", \"separator=/t\", \"-e\", \"frame.number\", \"-e\", \"usb.device_address\", \"-e\", \"usb.endpoint_address\", \"-e\", \"usb.capdata\"], \"stderr\": \"\", \"evidence_artifacts\": [{\"artifact\": \"work/pcap-usb-deb9b3c20ab5.tsv\", \"sha256\": \"526ecf8dccd07d02f9e9e515b3e9ad569cfc644ec9f0429319926172102027cd\", \"kind\": \"data_export\", \"source\": \"Actual offline TShark output; original PCAP preserved\"}], \"artifact\": \"work/pcap-usb-deb9b3c20ab5.tsv\", \"sha256\": \"526ecf8dccd07d02f9e9e515b3e9ad569cfc644ec9f0429319926172102027cd\"}\n",
    "stderr": "",
    "guest_log": "/home/kali/ctf-workbench/cases/ctf-04fca725df3de1d8/results/20261016T043330Z-c4a1a3bf.json",
    "guest_ip": "192.168.26.129",
    "transport_seconds": 0.515,
    "bridge_exit": 0,
    "case": "ctf-04fca725df3de1d8",
    "on": "kali",
    "transport": "verified_bridge"
  },
  "case": "ctf-04fca725df3de1d8",
  "upload_verified": true,
  "evidence_artifacts": [
    {
      "path": "[CTF_ROOT]\\.local\\bridge-runtime\\cases\\ctf-04fca725df3de1d8\\downloads\\20261016T043331Z-4026c315\\pcap-usb-deb9b3c20ab5.tsv",
      "sha256": "526ecf8dccd07d02f9e9e515b3e9ad569cfc644ec9f0429319926172102027cd",
      "kind": "data_export",
      "source": "Actual offline TShark output; original PCAP preserved"
    }
  ],
  "capture_errors": []
}
```

原始证据 SHA256：`6193b3528f59ddbf597f136751976f02220f5f553bd43634d9b58ba5ecbf3457`。

![步骤 13 的日志渲染图（非屏幕截图）](images/0013-log.png)

实际工具导出数据：[pcap-usb-deb9b3c20ab5.tsv](data/37152749418c4710aa4b804b21602885.tsv)。

### 步骤 15：math_gcd

时间：2026-10-16T04:34:05.336408+00:00；状态：成功返回；耗时：20.0 ms。

操作编号：`9f6ecae2895345cc88480db804647c61`。

**行动目的：** 自建重复检测验收，预期第三次收到提示

**实际操作与结果：**
```text
参数：
{
  "values": [
    48,
    60
  ],
  "wp_purpose": "自建重复检测验收，预期第三次收到提示",
  "wp_case": "ctf-04fca725df3de1d8"
}
实际返回：
{
  "result": 12
}
```

原始证据 SHA256：`54045070a98c363dce9567b5ad718c4a6a2962f94152570d8cd72ae4ac857f41`。

![步骤 15 的日志渲染图（非屏幕截图）](images/0015-log.png)

### 步骤 17：math_gcd

时间：2026-10-16T04:34:06.150526+00:00；状态：成功返回；耗时：25.5 ms。

操作编号：`91dd536753434d5e99b05eb63b9057c4`。

**行动目的：** 自建重复检测验收，预期第三次收到提示

**实际操作与结果：**
```text
参数：
{
  "values": [
    48,
    60
  ],
  "wp_purpose": "自建重复检测验收，预期第三次收到提示",
  "wp_case": "ctf-04fca725df3de1d8"
}
实际返回：
{
  "result": 12
}
```

原始证据 SHA256：`b2dfbea8dde4e43be53b5cf1fee6cef3283543e732d282d887f22bb16aefec77`。

![步骤 17 的日志渲染图（非屏幕截图）](images/0017-log.png)

### 步骤 19：math_gcd

时间：2026-10-16T04:34:06.974615+00:00；状态：成功返回；耗时：24.0 ms。

操作编号：`2c5ad0df96bb4253b4bb20b0c152a613`。

**行动目的：** 自建重复检测验收，预期第三次收到提示

**实际操作与结果：**
```text
参数：
{
  "values": [
    48,
    60
  ],
  "wp_purpose": "自建重复检测验收，预期第三次收到提示",
  "wp_case": "ctf-04fca725df3de1d8"
}
实际返回：
{
  "result": 12
}
```

原始证据 SHA256：`042b94cb5657601eacffb5f5ead5b35396ef2bc7437f990fd6570ab805b68c5d`。

![步骤 19 的日志渲染图（非屏幕截图）](images/0019-log.png)

### 步骤 21：ctf_task_health

时间：2026-10-16T04:34:07.707852+00:00；状态：成功返回；耗时：27.7 ms。

操作编号：`6bc42c3278ae4b4ba0cf41ad18c5345f`。

**行动目的：** 未单独填写；见实际操作。

**实际操作与结果：**
```text
参数：
{
  "wp_case": "ctf-04fca725df3de1d8",
  "case": "ctf-04fca725df3de1d8"
}
实际返回：
{
  "ok": true,
  "case": "ctf-04fca725df3de1d8",
  "calls": 9,
  "failed_calls": 0,
  "active_tool_seconds": 30.067,
  "recent_failure_streak": 0,
  "warnings": [
    {
      "code": "repeated_same_result",
      "count": 3,
      "tool": "math_gcd",
      "action": "相同参数与结果已重复；检查已有证据，换假设或交接。正常复查可注明 wp_repeat_expected=true。"
    }
  ],
  "policy": "advisory_only",
  "execution_blocked": false,
  "model_tokens": null,
  "model_cost": null,
  "scope": "仅统计经过本系统的新调用；不含模型推理时间或费用，不证明答案正确。"
}
```

原始证据 SHA256：`53e170401a0d3eee63645f42bd0f624a0cea0fba9e6018d1ae0c467d42ebd397`。

![步骤 21 的日志渲染图（非屏幕截图）](images/0021-log.png)

### 步骤 23：kb_search

时间：2026-10-16T04:34:08.426076+00:00；状态：失败（保留错误，不当作成功）；耗时：31.5 ms。

操作编号：`6f939b5d81e745fab843f319b90d3393`。

**行动目的：** 未单独填写；见实际操作。

**实际操作与结果：**
```text
参数：
{
  "source": "noobctf",
  "query": "NoobCTF",
  "wp_case": "ctf-04fca725df3de1d8"
}
实际返回：
{
  "ok": false,
  "tool": "kb_search",
  "error": "ValueError('noobctf 含题解/solver，独立解题和测评输入默认隔离；仅查阅参考案例时显式设置 allow_reference=true')",
  "error_code": "execution_failed",
  "wp_operation": {
    "operation_id": "6f939b5d81e745fab843f319b90d3393",
    "step": 22
  },
  "duration_ms": 31.5,
  "task_health": {
    "ok": true,
    "case": "ctf-04fca725df3de1d8",
    "calls": 11,
    "failed_calls": 1,
    "active_tool_seconds": 30.127,
    "recent_failure_streak": 1,
    "warnings": [],
    "policy": "advisory_only",
    "execution_blocked": false,
    "model_tokens": null,
    "model_cost": null,
    "scope": "仅统计经过本系统的新调用；不含模型推理时间或费用，不证明答案正确。"
  },
  "evidence_path": "[CTF_ROOT]\\logs\\calls\\1792125248402509700-caddb387.json"
}
```

原始证据 SHA256：`d7fe6ab540985479ca770c00b729bb8c731205361fbe01c42829156a2085045d`。

![步骤 23 的日志渲染图（非屏幕截图）](images/0023-log.png)

### 步骤 25：kb_search

时间：2026-10-16T04:34:09.118795+00:00；状态：成功返回；耗时：31.7 ms。

操作编号：`3e8e10c616404c3db0216911f2805a73`。

**行动目的：** 未单独填写；见实际操作。

**实际操作与结果：**
```text
参数：
{
  "source": "noobctf",
  "query": "NoobCTF",
  "allow_reference": true,
  "limit": 1,
  "wp_case": "ctf-04fca725df3de1d8"
}
实际返回：
{
  "query": "NoobCTF",
  "source": "noobctf",
  "normalized_terms": [
    "noobctf"
  ],
  "match_mode": "all_terms",
  "count": 1,
  "matches": [
    {
      "source": "noobctf",
      "path": "README.md",
      "title": "NoobCTF",
      "heading": "NoobCTF",
      "start_line": 1,
      "end_line": 9,
      "local_path": "[CTF_ROOT]\\references\\noobctf\\README.md",
      "file_sha256": "daff9c9fd023a24fcde9696082665d3ae8e1b38543687c028cddbe3a67ac3436",
      "commit": "0d9d8721f1c86f6529363fc63a6b915a1073ff77",
      "reference_only": true,
      "url": "https://github.com/Lo4pca/NoobCTF/blob/0d9d8721f1c86f6529363fc63a6b915a1073ff77/README.md#L1-L9",
      "excerpt": "# [NoobCTF]\n\n记录个人做题/学习时的笔记和一些writeup，leetcode解法记录。随着时间的推移，这个仓库的目标逐渐成为收集各个CTF的writeup。目标是一直更新，直到我不打CTF的那一天（希望这天别来）\n\n欢迎大家批评斧正以及交流分享。我尽量以纯小白的视角去记录每一道题，所以让所有人都能看懂是我的目标（我想由于“知识的诅咒”，现在我已经不具备纯小白视角了。但还是希望所有人都能看懂）。如果有任何解释不够清晰或不足的地方欢迎提出疑问，我会立刻查谷歌补充ʕ •ᴥ•ʔ\n\n打CTF最重要的就是开心了！Have fun！\n\n今天偶然注意到github自带的搜索（按`/`键）已经不覆盖web笔记后面的内容了，可能是文件太大了吧。还是`ctrl+f`好（",
      "rank": -8.36825
    }
  ],
  "trusted_instructions": false,
  "usage": "kb_read 需携带同一 source/path；参考题解库还需 allow_reference=true。检索命中不代表工具已安装、脚本已运行或答案已验证。"
}
```

原始证据 SHA256：`5f3725c249fb000cd67ca0399ad5a5f8a011d0eec8ea3cfab69c252e8043b690`。

![步骤 25 的日志渲染图（非屏幕截图）](images/0025-log.png)

### 步骤 27：kb_read

时间：2026-10-16T04:34:10.014904+00:00；状态：成功返回；耗时：93.8 ms。

操作编号：`b6ee547ab09b4fa5af6e66982674e766`。

**行动目的：** 未单独填写；见实际操作。

**实际操作与结果：**
```text
参数：
{
  "source": "noobctf",
  "path": "README.md",
  "start_line": 1,
  "lines": 4,
  "allow_reference": true,
  "wp_case": "ctf-04fca725df3de1d8"
}
实际返回：
{
  "source": "noobctf",
  "path": "README.md",
  "title": "NoobCTF",
  "heading": "NoobCTF",
  "start_line": 1,
  "end_line": 4,
  "local_path": "[CTF_ROOT]\\references\\noobctf\\README.md",
  "file_sha256": "daff9c9fd023a24fcde9696082665d3ae8e1b38543687c028cddbe3a67ac3436",
  "commit": "0d9d8721f1c86f6529363fc63a6b915a1073ff77",
  "reference_only": true,
  "url": "https://github.com/Lo4pca/NoobCTF/blob/0d9d8721f1c86f6529363fc63a6b915a1073ff77/README.md#L1-L4",
  "total_lines": 9,
  "text": "1: # NoobCTF\n2: \n3: 记录个人做题/学习时的笔记和一些writeup，leetcode解法记录。随着时间的推移，这个仓库的目标逐渐成为收集各个CTF的writeup。目标是一直更新，直到我不打CTF的那一天（希望这天别来）\n4: ",
  "more": true,
  "output_truncated": false,
  "trusted_instructions": false
}
```

原始证据 SHA256：`55232bd16db0cef6979810d925557723307b9afc9873610a33abad5ce22f1151`。

![步骤 27 的日志渲染图（非屏幕截图）](images/0027-log.png)

## 结果验证

当前没有被记录器识别的可信平台验证回执；已有计算或原程序验证请在观察说明中引用相应步骤。

## 未验证

- 自建样例六项 PCAP 操作实际通过；HTTP 导出内容待归档摘要核对。重复调用提示与参考资料隔离测试通过。本任务仅验收系统，不代表比赛题已解。

## 未完成

没有新增待办；最终解题状态以真实验证依据为准。

## 复现与证据

按上述命令、脚本与参数复现，核对实际输出和输入摘要。原始事件/回放保留失败过程。
终端 .cast 使用 asciinema play 查看；网页 trace.zip 使用 Playwright Trace Viewer 本地查看。
时间线共 28 条，末端摘要 `f50b4d5ceffbd69024242661a5da250423e0ad5248e7af19b9cc05fb3e68b43c`。
摘要用于发现本地意外改动，不是第三方签名。日志渲染图不属于屏幕截图。

本包包含私有原始证据与未经像素审阅的图像，分享版本需另行检查。
